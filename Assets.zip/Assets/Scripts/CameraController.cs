﻿using UnityEngine;
using System.Collections;

public class CameraController : MonoBehaviour
{
	void Start ()
	{
		LevelSystem.Instance.Hello();
	}
	
	void Update () {}
}