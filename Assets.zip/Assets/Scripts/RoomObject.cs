using System;
using UnityEngine;

public class RoomObject : MonoBehaviour
{
	#region Public Members
	public int width;
	public int height;
	public GameObject[] doors;
	#endregion
}