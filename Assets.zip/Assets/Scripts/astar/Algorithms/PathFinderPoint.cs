using System;

namespace Algorithms
{
	public struct PathFinderPoint
	{
		public int X; public int Y;
		
		public PathFinderPoint(int X, int Y)
		{
			this.X = X;
			this.Y = Y;
		}
	}
}

 
