﻿using UnityEngine;
using System.Collections;

public class Vec2i
{
	#region Public Members
	public int x;
	public int y;
	#endregion
	
	public Vec2i(int nx, int ny)
	{
		x = nx;
		y = ny;
	}
	
	public Vec2i() {}
}
